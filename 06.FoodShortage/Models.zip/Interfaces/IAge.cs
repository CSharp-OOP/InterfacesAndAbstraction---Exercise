﻿
namespace _06.FoodShortage.Interfaces
{
    interface IAge
    {
        int Age { get; }
    }
}